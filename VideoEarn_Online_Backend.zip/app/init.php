<?php
declare(strict_types=1);
require dirname(__DIR__).'/config.php';
if(strlen(APP_KEY)<48||str_contains(APP_KEY,'REPLACE_'))exit('Set a strong APP_KEY in config.php');
session_name('ve_session');session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>COOKIE_SECURE,'httponly'=>true,'samesite'=>'Lax']);ini_set('session.use_strict_mode','1');session_start();
function db():PDO{static $p=null;if(!$p)$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);return $p;}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function go($p){header('Location: '.$p);exit;}
function token(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">';}
function check(){if($_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Form expired');}}
function me(){if(empty($_SESSION['uid']))return null;$s=db()->prepare("SELECT * FROM users WHERE id=? AND status='active'");$s->execute([$_SESSION['uid']]);return $s->fetch()?:null;}
function admin(){if(empty($_SESSION['aid']))return null;$s=db()->prepare("SELECT * FROM admins WHERE id=? AND status='active'");$s->execute([$_SESSION['aid']]);return $s->fetch()?:null;}
function need(){if(!$u=me())go('/login');return $u;}
function needadmin(){if(!$a=admin())go('/admin/login');return $a;}
function bal($id){$s=db()->prepare("SELECT COALESCE(SUM(IF(direction='credit',amount,-amount)),0) FROM wallet WHERE user_id=?");$s->execute([$id]);return (int)$s->fetchColumn();}
function entry($uid,$amt,$dir,$why,$ref){$s=db()->prepare('INSERT INTO wallet(user_id,amount,direction,reason,reference) VALUES(?,?,?,?,?)');$s->execute([$uid,$amt,$dir,$why,$ref]);}
function audit($aid,$action,$target=null,$details=''){ $s=db()->prepare('INSERT INTO audit(admin_id,action,target_id,details) VALUES(?,?,?,?)');$s->execute([$aid,$action,$target,$details]);}
function page($title,$body,$admin=false){$u=me();echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' · VideoEarn</title><link rel="stylesheet" href="/assets/style.css"></head><body><header><b>VideoEarn</b><nav>';if($admin){foreach(['Dashboard'=>'/admin','Videos'=>'/admin/videos','Tasks'=>'/admin/tasks','Withdrawals'=>'/admin/withdrawals','Users'=>'/admin/users','Audit'=>'/admin/audit','Logout'=>'/admin/logout'] as $n=>$p)echo '<a href="'.$p.'">'.$n.'</a>';}elseif($u){foreach(['Dashboard'=>'/dashboard','Videos'=>'/videos','Wallet'=>'/wallet','Withdraw'=>'/withdraw','Logout'=>'/logout'] as $n=>$p)echo '<a href="'.$p.'">'.$n.'</a>';}else echo '<a href="/login">Login</a><a href="/register">Register</a><a href="/admin/login">Admin</a>';echo '</nav></header><main>'.$body.'</main><footer>VideoEarn · UGX rewards subject to review and funding.</footer></body></html>';}
function money($n){return 'UGX '.number_format((int)$n);}
function notice($s,$kind=''){return '<div class="notice '.$kind.'">'.e($s).'</div>';}
function safeurl($url){$p=parse_url($url);return $p&&($p['scheme']??'')==='https'&&in_array(strtolower($p['host']??''),['www.youtube-nocookie.com','www.youtube.com','player.vimeo.com'],true)&&str_starts_with($p['path']??'','/embed/');}

function auth_key($email){return hash_hmac('sha256',strtolower($email).'|'.($_SERVER['REMOTE_ADDR']??''),APP_KEY);}
function auth_locked($email){$q=db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_key=? AND created_at>NOW()-INTERVAL 15 MINUTE");$q->execute([auth_key($email)]);return (int)$q->fetchColumn()>=8;}
function auth_failed($email){$q=db()->prepare('INSERT INTO login_attempts(ip_key) VALUES(?)');$q->execute([auth_key($email)]);}
