# VideoEarn Online (PHP 8.2 + MySQL)

## Install
1. Create a MySQL database and import `database/schema.sql`.
2. Copy `config.example.php` to `config.php`; enter DB credentials, set `APP_URL`, and replace `APP_KEY` with at least 48 random characters.
3. Set the hosting document root to `public/`. Keep `app/`, `bin/`, `database/`, `storage/`, and `config.php` outside the public web root.
4. Enable HTTPS and keep `COOKIE_SECURE=true`.
5. Create the first admin from SSH: `php bin/create_admin.php admin@example.com`. It prompts for a password (minimum 14 characters).
6. Visit `/admin/login`.

## Included
User registration/login, video catalogue, task submissions requiring admin approval, UGX ledger, withdrawal requests, admin-only login, video/task/withdrawal/user management and audit log.

## Before public launch
This is a secure-oriented starter, not a completed payment processor or security certification. Add email verification, password reset, MFA, proxy/WAF rate limits, monitoring, backups, penetration testing, privacy/consumer/legal review, and official MTN/Airtel merchant integrations. Withdrawals are recorded for manual review; marking paid does not transfer funds. Never collect mobile-money PINs or OTPs. Browser-submitted views/shares are not proof of genuine engagement; review tasks and add provider-side verification/anti-fraud controls. Only fund rewards from verified revenue.
